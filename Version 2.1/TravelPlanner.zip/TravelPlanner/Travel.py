class Travel(object):

    def __init__(self, travel_id, datetime):
        self.datetime = datetime
        self.travel_id = travel_id
        self.title = "Travel"
        self.status = ""